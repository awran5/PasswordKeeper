import React, { useContext, useState, useEffect } from 'react'
import { AppContext } from '../../Context'
import { useAuthState } from 'react-firebase-hooks/auth'
import { useCollectionData } from 'react-firebase-hooks/firestore'
import Layout from '../Layout'
import { v4 as uuidv4 } from 'uuid'
import CryptoJS from 'crypto-js'
import Container from '@material-ui/core/Container'
import Grid from '@material-ui/core/Grid'
import { makeStyles } from '@material-ui/core/styles'
import { generatePassword } from '../../helper'
import Header from './Header'
import Hero from './Hero'
import PasswordCard from './PasswordCard'
import Modal from './Modal'
import Footer from './Footer'
import { Loading } from '../Loading'

const initialValues = {
  id: 0,
  title: '',
  password: '',
  length: 15,
  uppercase: true,
  numbers: true,
  symbols: true,
}

const initialErrorValues = {
  title: '',
  length: '',
  password: '',
}

interface PasswordList {
  createdAt: string
  password: string
  title: string
}

interface Users {
  createdAt: string
  displayName: string
  email: string
  id: string
  passwordList: PasswordList[]
  photoURL: string
}

const useStyles = makeStyles((theme) => ({
  main: {
    display: 'flex',
    flexGrow: 1,
  },
  cardGrid: {
    paddingTop: theme.spacing(8),
    paddingBottom: theme.spacing(8),
  },
}))

export default function App() {
  const classes = useStyles()
  const { firebase, cloudRef, Auth } = useContext(AppContext)
  const [currentUser] = useAuthState(Auth)
  const query = cloudRef('users').orderBy('createdAt')
  const [users, dbLoading, dbError] = useCollectionData<Users>(query, { idField: 'id' })

  const [modal, setModal] = useState(false)
  const [isRemove, setRemove] = useState(false)
  const [inputValues, setInputValues] = useState(initialValues)
  const [inputErrors, setInputErrors] = useState(initialErrorValues)
  const [storedValues, setStoredValues] = useState<PasswordList[]>([])

  useEffect(() => {
    users && users.map((user) => setStoredValues(user.passwordList))
    return () => setStoredValues([])
  }, [users])

  const handleReset = () => {
    if (modal) setModal(false)
    if (isRemove) setRemove(false)
    setInputValues(initialValues)
    setInputErrors(initialErrorValues)
    console.log('reset')
  }

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { type, checked, value, name } = event.target

    setInputErrors(initialErrorValues)
    setInputValues((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }))
  }

  const isValid = () => {
    const { title, password } = inputValues
    const storedTitle = storedValues.find((item) => item.title === title)

    if (!title) {
      setInputErrors((prev) => ({
        ...prev,
        title: 'Please add a password title',
      }))
      return false
    } else if (storedTitle) {
      setInputErrors((prev) => ({
        ...prev,
        title: 'You already have this title',
      }))
      return false
    }

    if (!password) {
      setInputErrors((prev) => ({
        ...prev,
        password: 'Please generate a password first',
      }))
      return false
    }
    return true
  }

  const handleOpenModal = () => setModal(true)
  const handleCloseModal = () => setModal(false)

  const handleRemoveModal = (index: number) => {
    // setRemove(true)
    // setModal(true)

    // setInputValues((prev) => ({
    //   ...prev,
    //   id: index,
    // }))

    let PasswordList: PasswordList[] = []

    users && users.map((user) => (PasswordList = user.passwordList))

    const itemMatch = PasswordList.filter((_, i) => i !== index)
    console.log(itemMatch)
  }

  const handleGenerate = () => {
    const { length, uppercase, numbers, symbols } = inputValues
    setInputErrors(initialErrorValues)

    if (length <= 6) {
      setInputErrors((prev) => ({
        ...prev,
        length: 'Password length must be at least 8 characters',
      }))
      return
    } else if (length > 25) {
      setInputErrors((prev) => ({
        ...prev,
        length: 'Maximum length allowed is 25 characters',
      }))
      return
    }

    setInputValues((prev) => ({
      ...prev,
      password: generatePassword(length, uppercase, numbers, symbols),
    }))
  }

  const handleAdd = async () => {
    const { title, password } = inputValues

    // Encrypt
    const encryptedPassword = CryptoJS.AES.encrypt(password, title).toString()

    await cloudRef('users')
      .doc(currentUser.uid)
      .update({
        passwordList: firebase.firestore.FieldValue.arrayUnion({
          title,
          password: encryptedPassword,
          createdAt: firebase.firestore.Timestamp.fromDate(new Date()),
        }),
      })
      .then(() => setModal(false))
      .catch((error) => console.log('Error adding document: ', error))
  }

  const handleRemove = async () => {
    const { id } = inputValues

    const newValues = storedValues.filter((_, index) => index !== id)

    await cloudRef('users')
      .doc(currentUser.uid)
      .update({
        passwordList: newValues,
      })
      .then(() => setModal(false))
      .catch((error) => console.log('Error removing document: ', error))
  }

  const handleSubmit = () => {
    if (isValid()) handleAdd()
    else if (isRemove) handleRemove()
  }

  return (
    <Layout>
      <Header />
      <Hero handleOpenModal={handleOpenModal} />
      <main className={classes.main}>
        <Container maxWidth='md' className={classes.cardGrid}>
          {!dbLoading ? (
            <PasswordCard handleRemoveModal={handleRemoveModal} storedValues={storedValues} />
          ) : (
            <Loading />
          )}
        </Container>
      </main>
      <Modal
        modal={modal}
        isRemove={isRemove}
        handleCloseModal={handleCloseModal}
        handleReset={handleReset}
        handleSubmit={handleSubmit}
        handleChange={handleChange}
        handleGenerate={handleGenerate}
        inputValues={inputValues}
        inputErrors={inputErrors}
      />
      <Footer />
    </Layout>
  )
}

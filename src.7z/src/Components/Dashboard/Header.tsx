import React, { useContext } from 'react'
import { AppContext } from '../../Context'
import { useAuthState } from 'react-firebase-hooks/auth'
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles'
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import Typography from '@material-ui/core/Typography'
import Avatar from '@material-ui/core/Avatar'
import IconButton from '@material-ui/core/IconButton'
import KeyIcon from '@material-ui/icons/VpnKey'
import MenuItem from '@material-ui/core/MenuItem'
import Menu from '@material-ui/core/Menu'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
  })
)

export default function Header() {
  const classes = useStyles()

  const { Auth } = useContext(AppContext)
  const [currentUser] = useAuthState(Auth)

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const open = Boolean(anchorEl)

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  return (
    <AppBar position='relative'>
      <Toolbar>
        <IconButton edge='start' className={classes.menuButton} color='inherit' aria-label='menu'>
          <KeyIcon />
        </IconButton>
        <Typography variant='h6' className={classes.title}>
          Photos
        </Typography>

        <div>
          <IconButton
            aria-label='account of current user'
            aria-controls='menu-appbar'
            aria-haspopup='true'
            onClick={handleMenu}
            color='inherit'
          >
            <Avatar alt={currentUser.displayName} src={currentUser.photoURL} />
          </IconButton>
          <Menu
            id='menu-appbar'
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={open}
            onClose={handleClose}
          >
            <MenuItem onClick={handleClose}>Profile</MenuItem>
            <MenuItem onClick={handleClose}>My account</MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  )
}

// import React, { useContext } from 'react'
// import { AppContext } from '../../Context'
// import { useAuthState } from 'react-firebase-hooks/auth'

// import AppBar from '@material-ui/core/AppBar'
// import Toolbar from '@material-ui/core/Toolbar'
// import VpnKeyIcon from '@material-ui/icons/VpnKey'
// import Typography from '@material-ui/core/Typography'
// import { makeStyles } from '@material-ui/core/styles'
// import IconButton from '@material-ui/core/IconButton'
// import Avatar from '@material-ui/core/Avatar'
// import MenuItem from '@material-ui/core/MenuItem'
// import Menu from '@material-ui/core/Menu'

// const useStyles = makeStyles((theme) => ({
//   root: {
//     flexGrow: 1,
//   },
//   icon: {
//     marginRight: theme.spacing(2),
//   },
//   avatar: {
//     width: theme.spacing(4),
//     height: theme.spacing(4),
//   },
// }))

// export default function Header() {
//   const classes = useStyles()
//   const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
//   const open = Boolean(anchorEl)

//   const { Auth } = useContext(AppContext)
//   const [currentUser] = useAuthState(Auth)

//   const handleClose = () => {
//     setAnchorEl(null)
//   }

//   return (
//     <div className={classes.root}>
//       <AppBar position='static'>
//         <Toolbar>
//           <VpnKeyIcon className={classes.icon} />
//           <Typography variant='h6' color='inherit' noWrap>
//             Password<strong>Vault</strong>
//           </Typography>
//           <div>
//             <IconButton
//               aria-label='account of current user'
//               aria-controls='menu-appbar'
//               aria-haspopup='true'
//               color='inherit'
//             >
//               <Avatar alt={currentUser.displayName} src={currentUser.photoURL} className={classes.avatar} />
//             </IconButton>
//             <Menu
//               id='menu-appbar'
//               anchorEl={anchorEl}
//               anchorOrigin={{
//                 vertical: 'top',
//                 horizontal: 'right',
//               }}
//               keepMounted
//               transformOrigin={{
//                 vertical: 'top',
//                 horizontal: 'right',
//               }}
//               open={open}
//               onClose={handleClose}
//             >
//               <MenuItem onClick={handleClose}>Profile</MenuItem>
//               <MenuItem onClick={handleClose}>My account</MenuItem>
//             </Menu>
//           </div>
//         </Toolbar>
//       </AppBar>
//     </div>
//   )
// }

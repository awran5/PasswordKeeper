import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import Container from '@material-ui/core/Container'
import Typography from '@material-ui/core/Typography'
import Link from '@material-ui/core/Link'

const useStyles = makeStyles((theme) => ({
  footer: {
    padding: theme.spacing(3),
    marginTop: 'auto',
    backgroundColor: '#fff',
  },
}))
export default function Footer() {
  const classes = useStyles()

  return (
    <footer className={classes.footer}>
      <Container maxWidth='md'>
        <Typography variant='h6' align='center'>
          Password<b>Vault</b>
        </Typography>
        <Typography variant='body2' align='center' color='textSecondary' gutterBottom style={{ padding: 10 }}>
          All passwords are saved to{' '}
          <Link
            title='Firebase'
            href='https://console.firebase.google.com/'
            component='a'
            rel='noopener noreferrer'
            target='_blank'
          >
            Firebase
          </Link>{' '}
          which is a platform developed by Google. In addition, we used{' '}
          <Link title='crypto' href='https://www.npmjs.com/package/crypto-js'>
            cryptoJS
          </Link>{' '}
          as a second layer of security that hashs all the stored passwords and ensure the maximum protection.
        </Typography>

        <Typography variant='body2' color='textSecondary' align='center'>
          {'Copyright © '}
          <Link color='inherit' href='https://github.com/awran5/'>
            awran5
          </Link>{' '}
          {new Date().getFullYear()}
          {'.'}
        </Typography>
      </Container>
    </footer>
  )
}

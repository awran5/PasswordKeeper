import React, { FC } from 'react'
import CryptoJS from 'crypto-js'
import Typography from '@material-ui/core/Typography'
import { makeStyles } from '@material-ui/core/styles'
import Container from '@material-ui/core/Container'
import Grid from '@material-ui/core/Grid'
import Card from '@material-ui/core/Card'
import CardActions from '@material-ui/core/CardActions'
import Button from '@material-ui/core/Button'

const useStyles = makeStyles((theme) => ({
  card: {
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(1, 2),
    justifyContent: 'space-between',
  },
}))

interface PasswordCardProps {
  handleRemoveModal: (index: number) => void
  storedValues: {
    title: string
    password: string
    createdAt: string
  }[]
}

const PasswordCard: FC<PasswordCardProps> = ({ handleRemoveModal, storedValues }) => {
  const classes = useStyles()

  const handleCopy = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>, title: string, password: string) => {
    if (!navigator.clipboard || password === '') return

    const button = event.target as HTMLInputElement

    // // Decrypt
    const bytes = CryptoJS.AES.decrypt(password, title)
    const decryptPassword = bytes.toString(CryptoJS.enc.Utf8)

    navigator.clipboard.writeText(decryptPassword).then(
      () => (button.innerText = 'copied'),
      (err) => console.error('Could not copy text: ', err)
    )

    setTimeout(() => (button.innerText = 'copy'), 1000)
  }

  return (
    <Grid container spacing={2}>
      {storedValues.length > 0 ? (
        storedValues.map(({ title, password }, index) => (
          <Grid item key={index} xs={12} sm={6}>
            <Card className={classes.card}>
              <Typography variant='subtitle1' component='h6'>
                {title}
              </Typography>
              <CardActions>
                <Button size='small' variant='outlined' color='secondary' onClick={() => handleRemoveModal(index)}>
                  remove
                </Button>
                <Button
                  size='small'
                  variant='contained'
                  color='primary'
                  onClick={(event) => handleCopy(event, title, password)}
                >
                  copy
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))
      ) : (
        <Typography variant='h5' align='center' color='textSecondary' style={{ width: '100%' }}>
          No Passwords
        </Typography>
      )}
    </Grid>
  )
}

export default PasswordCard

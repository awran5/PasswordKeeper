import React, { useContext } from 'react'
import { AppContext } from './Context'
import { useAuthState } from 'react-firebase-hooks/auth'
import { makeStyles } from '@material-ui/core/styles'
import CircularProgress from '@material-ui/core/CircularProgress'

import Dashboard from './Components/Dashboard'
import SignIn from './Components/SignIn'

const useStyles = makeStyles((theme) => ({
  loading: {
    width: '100vw',
    height: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
}))

const App = () => {
  const classes = useStyles()

  const { Auth } = useContext(AppContext)
  const [user, loading, error] = useAuthState(Auth)
  if (error) return <h1>Error: {error}</h1>
  if (loading)
    return (
      <div className={classes.loading}>
        <CircularProgress size={60} />
      </div>
    )

  return <React.Fragment>{user ? <Dashboard /> : <SignIn />}</React.Fragment>
}

export default App

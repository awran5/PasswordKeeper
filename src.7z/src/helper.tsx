function arrayRange(from: number, to: number) {
  const array = []
  for (let i = from; i <= to; i++) {
    array.push(i)
  }
  return array
}

/**
 * Returns a random string that generated from a specified sequence of UTF-8/16 character codes then convert them using 'fromCharCode'.
 * @link https://www.w3schools.com/charsets/ref_html_utf8.asp
 * @link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/fromCharCode
 * @tutorial https://www.youtube.com/watch?v=iKo9pDKKHnc&t=59s
 * @returns string
 */

export function generatePassword(
  charlength: number,
  includeUppercase?: boolean,
  includeNumbers?: boolean,
  includeSymbols?: boolean
): string {
  const getLowerCase = arrayRange(97, 122)
  const getUpperCase = arrayRange(65, 90)
  const getNumbers = arrayRange(48, 57)
  const getSymbol = [...arrayRange(33, 47), ...arrayRange(58, 64), ...arrayRange(91, 96), ...arrayRange(123, 126)]
  const passwords = []
  let charCodes = getLowerCase

  if (includeUppercase) charCodes = [...charCodes, ...getUpperCase]
  if (includeNumbers) charCodes = [...charCodes, ...getNumbers]
  if (includeSymbols) charCodes = [...charCodes, ...getSymbol]

  for (let i = 0; i < charlength; i++) {
    const characterCode = charCodes[Math.floor(Math.random() * charCodes.length)]
    passwords.push(String.fromCharCode(characterCode))
  }

  return passwords.join('')
}
